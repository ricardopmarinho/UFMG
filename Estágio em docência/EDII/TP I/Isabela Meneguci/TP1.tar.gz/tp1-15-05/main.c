#include<stdlib.h>
#include<stdio.h>
#include"tad.h" 

int main( int argc, char *argv[] ){
printf("CASO INICIAL:\n");
caso1(1);
printf("\nCASO 2: \n");
caso2(2);
printf("\nCASO 3: \n");
caso3(3);
printf("\nCASO Aleatorio: \n");
caso3(4);
}

