#include<stdio.h>
#include <stdlib.h>

#include<stdio.h>
#include <stdlib.h>

typedef struct {
 int Topo;
} TPilha;

void FPVazia(TPilha *Pilha);

int Vazia(TPilha Pilha);

void Empilha10(TPilha *Pilha);

void Desempilha(TPilha *Pilha);

int Tamanho(TPilha Pilha);
