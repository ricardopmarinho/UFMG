#include "tp_pilha.c"
#include "tp_fila.c"
#include <stdio.h>

void DesenfileiraEnfileira(TFila *FilaS, TFila *FilaE);

int PegarBandeja(TPilha *pilha_bandejas, TFila *bet);
