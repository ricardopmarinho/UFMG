Trabalho feito por:
Guilherme Teres Nunes

Para ver o trabalho, basta abrir o arquivo Source/AEDS_II_TP1.cbp usando o Code::Blocks.