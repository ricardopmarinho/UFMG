#ifndef __TIME_H__
#define __TIME_H__

#include <stddef.h>


typedef size_t time;  // Time in minutes.


#endif /* __TIME_H__ */
